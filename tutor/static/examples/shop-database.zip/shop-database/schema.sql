CREATE TABLE customers (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  city TEXT NOT NULL
);
CREATE TABLE products (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  price REAL NOT NULL
);
CREATE TABLE orders (
  id INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  status TEXT NOT NULL
);
CREATE TABLE lines (
  order_id INTEGER NOT NULL REFERENCES orders(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  qty INTEGER NOT NULL,
  PRIMARY KEY (order_id, product_id)
);
CREATE VIEW order_totals AS
  SELECT o.id AS order_id, c.name AS customer, o.status,
         ROUND(SUM(p.price * l.qty), 2) AS total
  FROM orders o
  JOIN customers c ON c.id = o.customer_id
  JOIN lines l ON l.order_id = o.id
  JOIN products p ON p.id = l.product_id
  GROUP BY o.id;
CREATE VIEW big_spenders AS
  SELECT customer AS name, SUM(total) AS spent
  FROM order_totals
  GROUP BY customer
  HAVING SUM(total) > 100;
