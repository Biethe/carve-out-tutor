INSERT INTO customers VALUES (1, 'Ada', 'Lagos'), (2, 'Bob', 'Paris'), (3, 'Cy', 'Lagos');
INSERT INTO orders VALUES (1, 1, 80), (2, 1, 45.5), (3, 2, 20), (4, 3, 150);
