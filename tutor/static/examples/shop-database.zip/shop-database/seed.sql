INSERT INTO customers VALUES
  (1, 'Ada', 'Lagos'),
  (2, 'Bob', 'Paris'),
  (3, 'Cy', 'Lagos'),
  (4, 'Diya', 'Nairobi');
INSERT INTO products VALUES
  (1, 'Notebook', 12),
  (2, 'Ink', 8.5),
  (3, 'Lamp', 46),
  (4, 'Chair', 120),
  (5, 'Mug', 9);
INSERT INTO orders VALUES
  (1, 1, 'paid'),
  (2, 1, 'open'),
  (3, 2, 'paid'),
  (4, 3, 'paid'),
  (5, 4, 'open');
INSERT INTO lines VALUES
  (1, 1, 2),
  (1, 2, 1),
  (2, 3, 1),
  (3, 5, 3),
  (4, 4, 1),
  (4, 3, 1),
  (5, 1, 4),
  (5, 5, 2);
