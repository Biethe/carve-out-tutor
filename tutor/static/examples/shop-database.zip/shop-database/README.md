# Shop database

A shop's database in SQL: customers and their orders (schema.sql), some sample rows (seed.sql), a view of the customers who spent the most, and the queries the shop runs (queries.sql). Made for Carve-Out to take apart one table, view or query at a time. Runs on SQLite.
