# Corner shop

A small shop in SQL: customers, products, orders and the lines on each order. `order_totals` and `big_spenders` are views. The named queries in `queries.sql` are the reports.
