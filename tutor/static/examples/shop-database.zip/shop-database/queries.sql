-- name: customers_per_city
SELECT city, COUNT(*) AS customers FROM customers GROUP BY city ORDER BY customers DESC, city;

-- name: orders_with_names
SELECT o.id, c.name, o.total FROM orders o JOIN customers c ON c.id = o.customer_id ORDER BY o.id;
