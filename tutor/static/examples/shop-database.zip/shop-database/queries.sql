-- name: customers_per_city
SELECT city, COUNT(*) AS customers
FROM customers
GROUP BY city
ORDER BY customers DESC, city;

-- name: orders_with_names
SELECT order_id, customer, status, total
FROM order_totals
ORDER BY order_id;

-- name: revenue_by_product
SELECT p.name, SUM(l.qty) AS sold, ROUND(SUM(p.price * l.qty), 2) AS revenue
FROM products p
JOIN lines l ON l.product_id = p.id
GROUP BY p.id
ORDER BY revenue DESC;

-- name: open_orders
SELECT order_id, customer, total
FROM order_totals
WHERE status = 'open'
ORDER BY total DESC;
