// The list's rules, on plain data. The page only draws what these return.

export function addTodo(list, text) {
  const clean = text.trim();
  if (!clean) return list;
  const id = list.reduce((max, t) => Math.max(max, t.id), 0) + 1;
  return [...list, { id, text: clean, done: false }];
}

export function toggle(list, id) {
  return list.map((t) => (t.id === id ? { ...t, done: !t.done } : t));
}

export function removeTodo(list, id) {
  return list.filter((t) => t.id !== id);
}

export function editTodo(list, id, text) {
  const clean = text.trim();
  if (!clean) return removeTodo(list, id);
  return list.map((t) => (t.id === id ? { ...t, text: clean } : t));
}

export function clearDone(list) {
  return list.filter((t) => !t.done);
}

export function remaining(list) {
  return list.filter((t) => !t.done).length;
}

export function filterBy(list, filter) {
  if (filter === "done") return list.filter((t) => t.done);
  if (filter === "open") return list.filter((t) => !t.done);
  return list;
}
