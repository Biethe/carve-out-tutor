import { addTodo, toggle, removeTodo, editTodo, clearDone, remaining, filterBy } from "./todo.js";

let todos = [];
let filter = "all";

function render() {
  const list = document.getElementById("list");
  const shown = filterBy(todos, filter);
  list.innerHTML = "";
  document.getElementById("empty").hidden = shown.length > 0;
  for (const t of shown) {
    const li = document.createElement("li");
    li.className = t.done ? "done" : "";
    const box = document.createElement("button");
    box.className = "check";
    box.type = "button";
    box.setAttribute("aria-label", t.done ? "Mark not done" : "Mark done");
    box.onclick = () => { todos = toggle(todos, t.id); render(); };
    const label = document.createElement("span");
    label.className = "text";
    label.textContent = t.text;
    label.ondblclick = () => startEdit(li, t);
    const del = document.createElement("button");
    del.className = "remove";
    del.type = "button";
    del.textContent = "Remove";
    del.onclick = () => { todos = removeTodo(todos, t.id); render(); };
    li.append(box, label, del);
    list.append(li);
  }
  document.getElementById("left").textContent = remaining(todos);
  document.getElementById("clear").hidden = remaining(todos) === todos.length;
  for (const btn of document.querySelectorAll("[data-filter]")) {
    btn.setAttribute("aria-pressed", String(btn.dataset.filter === filter));
  }
}

function startEdit(li, t) {
  const input = document.createElement("input");
  input.value = t.text;
  input.className = "edit";
  li.querySelector(".text").replaceWith(input);
  input.focus();
  const finish = () => {
    todos = editTodo(todos, t.id, input.value);
    render();
  };
  input.onblur = finish;
  input.onkeydown = (e) => { if (e.key === "Enter") input.blur(); if (e.key === "Escape") { input.value = t.text; input.blur(); } };
}

document.getElementById("add-form").onsubmit = (e) => {
  e.preventDefault();
  const field = document.getElementById("new-text");
  todos = addTodo(todos, field.value);
  field.value = "";
  render();
};

document.getElementById("filters").onclick = (e) => {
  const btn = e.target.closest("[data-filter]");
  if (!btn) return;
  filter = btn.dataset.filter;
  render();
};

document.getElementById("clear").onclick = () => { todos = clearDone(todos); render(); };
render();
