import { addTodo, toggle, remaining } from "./todo.js";

let todos = [];

function render() {
  const list = document.getElementById("list");
  list.innerHTML = "";
  for (const t of todos) {
    const li = document.createElement("li");
    li.textContent = t.text;
    li.className = t.done ? "done" : "";
    li.onclick = () => { todos = toggle(todos, t.id); render(); };
    list.append(li);
  }
  document.getElementById("left").textContent = remaining(todos);
}

document.getElementById("add-form").onsubmit = (e) => {
  e.preventDefault();
  todos = addTodo(todos, document.getElementById("new-text").value);
  document.getElementById("new-text").value = "";
  render();
};
render();
