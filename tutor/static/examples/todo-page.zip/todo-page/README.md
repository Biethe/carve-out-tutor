# Todo page

A small todo list that runs in the browser: a page (index.html), its styles (style.css), the list's logic as plain functions (src/todo.js) and the code that connects them to the page (src/app.js). Made for Carve-Out as a first web project to take apart.
