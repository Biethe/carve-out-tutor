# Field notes

A small to-do page: add, rename, finish, filter, and clear. The rules live in `src/todo.js`. The page in `src/app.js` only draws them.
